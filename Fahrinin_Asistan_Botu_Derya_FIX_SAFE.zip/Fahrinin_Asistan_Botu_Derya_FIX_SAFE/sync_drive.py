
import os
import sys
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.join(BASE_DIR, "config")
SYNC_CONFIG_PATH = os.path.join(CONFIG_DIR, "sync_config.yaml")
DRIVE_CONFIG_PATH = os.path.join(CONFIG_DIR, "drive_config.yaml")


def read_yaml_value(path, key):
    """Basit YAML satir okuyucu: key: value satirindan value'yu alir."""
    if not os.path.exists(path):
        print(f"[HATA] {path} bulunamadi.")
        sys.exit(1)

    value = None
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.lower().startswith(key.lower()):
                parts = line.split(":", 1)
                if len(parts) == 2:
                    value = parts[1].strip().strip('"').strip("'")
                    break

    if not value:
        print(f"[HATA] {os.path.basename(path)} icinde {key} bulunamadi.")
        sys.exit(1)

    return value


def find_creds_path():
    """drive_config.yaml ve config klasorune bakarak JSON kimlik dosyasini bulur."""
    candidates = []

    # 1) drive_config.yaml icindeki yolu dene
    if os.path.exists(DRIVE_CONFIG_PATH):
        try:
            rel = read_yaml_value(DRIVE_CONFIG_PATH, "google_credentials_file")
        except SystemExit:
            rel = None

        if rel:
            if os.path.isabs(rel):
                candidates.append(rel)
            else:
                candidates.append(os.path.join(BASE_DIR, rel))
                candidates.append(os.path.join(CONFIG_DIR, rel))

    # 2) config klasorundeki tum .json dosyalarini aday olarak ekle
    if os.path.exists(CONFIG_DIR):
        for fname in os.listdir(CONFIG_DIR):
            if fname.lower().endswith(".json"):
                candidates.append(os.path.join(CONFIG_DIR, fname))

    checked = set()
    for path in candidates:
        path = os.path.normpath(path)
        if path in checked:
            continue
        checked.add(path)
        if os.path.exists(path):
            print(f"[INFO] Kimlik dosyasi bulundu: {path}")
            return path

    print("[HATA] Hicbir kimlik (.json) dosyasi bulunamadi.")
    print("Lutfen config klasorunde service account JSON dosyasi oldugundan emin ol.")
    sys.exit(1)


def setup_drive_service(creds_file_path):
    """Google Drive service olusturur."""
    try:
        from google.oauth2 import service_account
        from googleapiclient.discovery import build
    except ImportError:
        print("[HATA] Google Drive kutuphaneleri yuklu degil.")
        print("Komut satirinda su komutu calistir askim:")
        print("    pip install --upgrade google-api-python-client google-auth-httplib2 google-auth-oauthlib")
        sys.exit(1)

    if not os.path.exists(creds_file_path):
        print(f"[HATA] Kimlik dosyasi bulunamadi: {creds_file_path}")
        sys.exit(1)

    scopes = ["https://www.googleapis.com/auth/drive.file"]
    creds = service_account.Credentials.from_service_account_file(
        creds_file_path, scopes=scopes
    )
    service = build("drive", "v3", credentials=creds)
    return service


def get_or_create_folder(service, folder_name):
    """Drive'da klasor arar, yoksa olusturur."""
    query = (
        f"name = '{folder_name}' and "
        f"mimeType = 'application/vnd.google-apps.folder' and "
        f"trashed = false"
    )

    results = (
        service.files()
        .list(q=query, spaces="drive", fields="files(id, name)", pageSize=1)
        .execute()
    )
    items = results.get("files", [])
    if items:
        folder_id = items[0]["id"]
        print(f"[INFO] Var olan klasor kullaniliyor: {folder_name} (id={folder_id})")
        return folder_id

    file_metadata = {
        "name": folder_name,
        "mimeType": "application/vnd.google-apps.folder",
    }
    folder = service.files().create(body=file_metadata, fields="id").execute()
    folder_id = folder.get("id")
    print(f"[INFO] Yeni klasor olusturuldu: {folder_name} (id={folder_id})")
    return folder_id


def upload_or_update_file(service, folder_id, local_path, rel_path):
    """Dosyayi Drive'a yukler ya da gunceller."""
    from googleapiclient.http import MediaFileUpload

    query = (
        f"name = '{rel_path}' and "
        f"'{folder_id}' in parents and "
        f"trashed = false"
    )

    results = (
        service.files()
        .list(q=query, spaces="drive", fields="files(id, name)", pageSize=1)
        .execute()
    )
    items = results.get("files", [])

    media = MediaFileUpload(local_path, resumable=False)

    if items:
        file_id = items[0]["id"]
        service.files().update(fileId=file_id, media_body=media).execute()
        print(f"[OK] Guncellendi: {rel_path}")
    else:
        file_metadata = {"name": rel_path, "parents": [folder_id]}
        service.files().create(
            body=file_metadata, media_body=media, fields="id"
        ).execute()
        print(f"[OK] Yuklendi: {rel_path}")


def main():
    print("=== DERYA SYNC PY calisiyor (Drive entegre) ===")

    # 1) Yerel klasor yolunu oku
    local_folder = read_yaml_value(SYNC_CONFIG_PATH, "drive_sync_path")
    print(f"Kullanilan yerel klasor: {local_folder}")

    if not os.path.exists(local_folder):
        print(f"[UYARI] {local_folder} yok, olusturuluyor...")
        os.makedirs(local_folder, exist_ok=True)

    # 2) Kimlik dosyasi yolunu akilli sekilde bul
    creds_path = find_creds_path()

    # 3) Drive klasor adini oku
    drive_folder_name = read_yaml_value(DRIVE_CONFIG_PATH, "drive_folder_name")

    # 4) Drive service olustur
    service = setup_drive_service(creds_path)

    # 5) Drive klasorunu al/olustur
    folder_id = get_or_create_folder(service, drive_folder_name)

    # 6) Yerel klasordeki dosyalari Drive'a senkronla
    files_count = 0
    for root, dirs, files in os.walk(local_folder):
        for fname in files:
            if fname.lower() == "sync_log.txt":
                continue

            full_path = os.path.join(root, fname)
            rel_path = os.path.relpath(full_path, local_folder)

            upload_or_update_file(service, folder_id, full_path, rel_path)
            files_count += 1

    # 7) Log dosyasina yaz
    log_path = os.path.join(local_folder, "sync_log.txt")
    with open(log_path, "a", encoding="utf-8") as log:
        log.write(
            f"{datetime.now().isoformat()} - Drive sync tamamlandi. Dosya sayisi: {files_count}\n"
        )

    print(f"Drive senkron tamamlandi askim. Toplam islenen dosya: {files_count}")
    print("=============================================")


if __name__ == "__main__":
    main()
