
# DERYA_FINAL_AUTO_RUN (Hizli Kullanım)

1) ZIP'i cikarin (sag tikla -> Buraya cikar). 
2) `INSTALL_ALL.bat` dosyasini **yonetici olmadan** calistirin (cift tik). 
   - Python kutuphaneleri otomatik yuklenir.
3) Web arayuzu icin: `RUN_FULL.bat`
   - Tarayicinizda http://127.0.0.1:5000 acilir.
4) Tam senkron icin: `RUN_SYNC.bat`
5) Her seferinde dogrudan arayuzu acmak icin: `OPEN_SOCIALS.bat`

> Notlar
- Proje klasor adi: **Fahrinin_Asistan_Botu_Derya_FIX** (Desktop'ta olmali).
- `config` klasorundaki `.env`, `tele_config.yaml`, `metricool_connect.yaml` sizde mevcut olanlarla calisir.
- Hata olursa ekran goruntusu gonderin.
